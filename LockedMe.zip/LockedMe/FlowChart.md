# Flow Chart

This document outlines the flow of the LockedMe.com application. The flow chart is designed to provide a visual representation of the application's processes and the sequence of actions that are performed.

## Application Flow

1. **Start:** The application starts.
2. **Display Welcome Screen:** The application displays the welcome screen with the application name and developer details.
3. **Display User Interface Options:** The application displays the user interface options and waits for the user to select an option.
4. **User Input:** The user selects an option.
5. **Process User Input:** Depending on the user's selection, the application performs one of the following actions:
    - **Option 1:** Display the current file names in ascending order.
    - **Option 2:** Display the user interface options for file management, which include:
        - Add a file to the existing directory list.
        - Delete a user-specified file from the existing directory list.
        - Search for a user-specified file from the main directory.
    - **Option 3:** Close the application.
6. **Display Result:** The application displays the result of the action. If the action was successful, a success message is displayed. If the action was unsuccessful, an error message is displayed.
7. **Return to Main Context:** Unless the application was closed, the application returns to the main context and displays the user interface options again.
8. **End:** The application ends when the user selects the option to close the application.

## Flow Chart Diagram

The flow chart diagram provides a visual representation of the application flow. The diagram is created using standard flowchart symbols, with rectangles representing processes, diamonds representing decisions, and arrows representing the flow of control.

```
Start
  |
  V
Display Welcome Screen
  |
  V
Display User Interface Options
  |
  V
User Input
  |
  V
Process User Input
  |          |          |
  V          V          V
Option 1  Option 2  Option 3
  |          |          |
  V          V          V
Display   Display   Close Application
File Names  File Management Options
  |          |
  V          V
Display Result  Process File Management Input
  |          |
  V          V
Return to Main Context  Display Result
  |          |
  V          V
Display User Interface Options  Return to Main Context
  |          |
  V          V
User Input  Display User Interface Options
  |          |
  V          V
Process User Input  User Input
  |          |
  V          V
End       Process User Input
```

