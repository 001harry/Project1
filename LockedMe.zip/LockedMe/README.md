# LockedMe.com Prototype Application

This is a command line application developed for Company Lockers Pvt. Ltd. as a prototype for their first project, LockedMe.com. The application is designed to manage files within a directory, providing options to display file names in ascending order, add a file, delete a file, search for a file, and close the application.

## Developer Details
This application is developed by [Your Name], a Full Stack Developer at Company Lockers Pvt. Ltd.

## Features
1. Retrieve all file names in the directory in ascending order.
2. Add a file to the directory.
3. Delete a file from the directory.
4. Search for a file in the directory.
5. Close the application.

## Technologies Used
- Java
- Git
- GitHub
- Eclipse/IntelliJ

## Agile Framework Used
Scrum

## Data Structures Used
Search and Sort techniques

## How to Use
1. Clone the repository to your local machine.
2. Open the project in your preferred IDE (Eclipse/IntelliJ).
3. Run the Main.java file to start the application.
4. Follow the prompts in the command line to use the features of the application.

## Documentation
For more details about the planning and development of this application, please refer to the following documents in the repository:

- [Specification Document](./SpecificationDocument.md)
- [Sprint Plan](./SprintPlan.md)
- [Flow Chart](./FlowChart.md)

## Repository Link
[GitHub Repository](https://github.com/yourusername/lockedme)

## Conclusion
This application is a simple yet powerful tool for managing files within a directory. It is user-friendly and efficient, making it a valuable asset for any user. The application is also scalable, allowing for additional features and improvements to be added in the future.

## Unique Selling Points
- User-friendly command line interface.
- Efficient file management.
- Scalability for future enhancements.
