java
import java.util.Scanner;

public class Main {

    private static final FileManager fileManager = new FileManager();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        displayWelcomeScreen();
        interactWithUser();
    }

    private static void displayWelcomeScreen() {
        System.out.println("Welcome to LockedMe.com Prototype Application");
        System.out.println("Developed by [Your Name]");
        System.out.println("--------------------------------------------------");
    }

    private static void interactWithUser() {
        while (true) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline left-over
            switch (choice) {
                case 1:
                    fileManager.displayFilesInAscendingOrder();
                    break;
                case 2:
                    interactWithFileOperations();
                    break;
                case 3:
                    System.out.println("Exiting the application...");
                    System.exit(0);
                default:
                    System.out.println("Invalid input provided, please choose a valid option");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\n\n--------------------------------------------------");
        System.out.println("Please choose from the following options:");
        System.out.println("1. Display current file names in ascending order");
        System.out.println("2. File Operations (Add, Delete, Search)");
        System.out.println("3. Exit the application");
        System.out.println("--------------------------------------------------");
    }

    private static void interactWithFileOperations() {
        while (true) {
            displayFileOperationsMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline left-over
            switch (choice) {
                case 1:
                    System.out.println("Please enter the name of the file to add:");
                    String fileToAdd = scanner.nextLine();
                    fileManager.addFile(fileToAdd);
                    break;
                case 2:
                    System.out.println("Please enter the name of the file to delete:");
                    String fileToDelete = scanner.nextLine();
                    fileManager.deleteFile(fileToDelete);
                    break;
                case 3:
                    System.out.println("Please enter the name of the file to search:");
                    String fileToSearch = scanner.nextLine();
                    fileManager.searchFile(fileToSearch);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid input provided, please choose a valid option");
            }
        }
    }

    private static void displayFileOperationsMenu() {
        System.out.println("\n\n--------------------------------------------------");
        System.out.println("Please choose from the following options:");
        System.out.println("1. Add a file to the directory");
        System.out.println("2. Delete a file from the directory");
        System.out.println("3. Search a file from the directory");
        System.out.println("4. Go back to the main context");
        System.out.println("--------------------------------------------------");
    }
}

