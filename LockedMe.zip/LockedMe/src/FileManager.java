java
import java.io.File;
import java.util.Arrays;

public class FileManager {

    private static final String DIRECTORY = "./";

    public void displayFilesInAscendingOrder() {
        File dir = new File(DIRECTORY);
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            System.out.println("The directory is empty");
        } else {
            Arrays.sort(files);
            System.out.println("Files in " + DIRECTORY + " in ascending order:");
            for (File file : files) {
                System.out.println(file.getName());
            }
        }
    }

    public void addFile(String fileName) {
        File file = new File(DIRECTORY + fileName);
        try {
            if (file.createNewFile()) {
                System.out.println(fileName + " has been created successfully");
            } else {
                System.out.println(fileName + " already exists");
            }
        } catch (Exception e) {
            System.out.println("An error occurred");
            e.printStackTrace();
        }
    }

    public void deleteFile(String fileName) {
        File file = new File(DIRECTORY + fileName);
        if (file.delete()) {
            System.out.println(fileName + " has been deleted successfully");
        } else {
            System.out.println("Failed to delete " + fileName + ", file not found");
        }
    }

    public void searchFile(String fileName) {
        File file = new File(DIRECTORY + fileName);
        if (file.exists()) {
            System.out.println(fileName + " was found in the directory");
        } else {
            System.out.println(fileName + " does not exist in the directory");
        }
    }
}

