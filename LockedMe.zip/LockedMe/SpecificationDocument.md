# Specification Document

## Project Details

This project is a prototype application for Company Lockers Pvt. Ltd.'s first project, LockedMe.com. The application is a command line interface that allows users to manage files within a directory. The features of the application include displaying file names in ascending order, adding a file, deleting a file, searching for a file, and closing the application.

## Developer Details

This application is developed by a Full Stack Developer at Company Lockers Pvt. Ltd.

## Sprints Planned

The development of this application is planned in more than two sprints. Each sprint focuses on developing and testing a specific set of features. The details of the sprints and the tasks achieved in them are documented in the [Sprint Plan](./SprintPlan.md).

## Algorithms and Flowcharts

The algorithms and flowcharts used in the development of this application are documented in the [Flow Chart](./FlowChart.md). The algorithms include search and sort techniques for managing the files in the directory.

## Core Concepts Used

The core concepts used in this project include:

- Java programming language for developing the application.
- Git for version control and tracking changes in the source code.
- GitHub for storing the source code and tracking its versions.
- Scrum as an agile framework for delivering the product incrementally.
- Search and sort techniques as data structures for managing the files in the directory.

## GitHub Repository

The source code of the application is stored in the GitHub repository.

## Conclusion on Enhancing the Application

The application is designed with scalability in mind, allowing for additional features and improvements to be added in the future. Potential enhancements could include more advanced file management features, such as moving files between directories, renaming files, and viewing file details.

## Unique Selling Points

The unique selling points of this application include:

- User-friendly command line interface: The application is easy to use, with clear prompts and instructions for the user.
- Efficient file management: The application provides a simple and efficient way to manage files within a directory.
- Scalability: The application is designed to be scalable, allowing for future enhancements and additional features.
